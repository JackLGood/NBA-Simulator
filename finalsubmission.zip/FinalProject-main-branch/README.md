Final Project: CS3110
OCaml NBA Simulator 2024

Jack Good (jlg444@cornell.edu)
Jordan Ibe (cji26@cornell.edu)
Jeremy Cortez (jac722@cornell.edu)
Andres Ruah (ar2436@cornell.edu)

Our project is an interactive tool that allows users to create, manage, and compete 
with custom basketball teams. The simulator supports multiple gameplay modes, 
including regular season, playoffs, and tournament simulations. It calculates game 
outcomes using sophisticated player and team rating algorithms that take into account 
individual statistics and team dynamics. Users can customize and add new players through 
an intuitive player creation interface, which updates player attributes dynamically.

The project provides an immersive simulation experience by incorporating features like 
visually formatted brackets, leaderboards, and real-time game progress updates. Through a 
clean and user-friendly command-line interface, users can navigate between different 
functionalities, set up teams, and observe how their decisions impact game outcomes. The 
modular design ensures scalability, making it easy to add future features or expand the 
simulation's scope. By combining detailed statistical calculations with engaging gameplay 
mechanics, the simulator offers an entertaining and analytical exploration of basketball 
strategy and competition.

The interface runs on the command line with rich visuals of NBA season progression.
